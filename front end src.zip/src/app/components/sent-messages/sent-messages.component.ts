import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-sent-messages',
  templateUrl: './sent-messages.component.html',
  styleUrls: ['./sent-messages.component.scss']
})
export class SentMessagesComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
