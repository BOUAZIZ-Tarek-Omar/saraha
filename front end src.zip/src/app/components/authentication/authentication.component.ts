import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';

@Component({
  selector: 'app-authentication',
  templateUrl: './authentication.component.html',
 // template:'',
  styleUrls: ['./authentication.component.scss']
})
export class AuthenticationComponent implements OnInit {

  constructor(
    //injection de dep
    //service ou utils
private router: Router
  ) { }

  ngOnInit(): void {
  }

  async redirectToRegister():Promise<void> {
await this.router.navigate(['register']);// no need '/'
  }

  async connect():Promise<void> {
//todo implement login
    await this.router.navigate(['home'])
  }
}
